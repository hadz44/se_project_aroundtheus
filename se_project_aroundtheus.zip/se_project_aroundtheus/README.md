# Project 3: Around The U.S.

# This is the first time we used the application FIGMA. We had to make a website based on the design given. We also need to make sure that all the elements are accurately displayed on different screens.

# The technologies that were used are:

1.FIGMA
2.CSS
3.HTML
4.Grid
5.Flexbox

# As for my Github link:https://github.com/hadz44/se_project_aroundtheus/tree/main/se_project_aroundtheus
